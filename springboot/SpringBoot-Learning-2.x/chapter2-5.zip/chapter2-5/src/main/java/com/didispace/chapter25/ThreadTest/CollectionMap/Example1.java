package com.didispace.chapter25.ThreadTest.CollectionMap;

public class Example1 {

    public final static Integer a=1;




}
