package com.didispace.chapter25.ThreadTest.finlaExample;



import com.google.common.collect.Maps;


import java.util.Map;


public class FinalClassExample {

    private  final  static  Integer a=0;
    private  final  static  String  b ="2";
    private  final  static Map<Integer,Integer> c= Maps.newHashMap();


}

