
<a name="definitions"></a>
## Definitions

<a name="user"></a>
### User
用户实体


|Name|Description|Schema|
|---|---|---|
|**age**  <br>*optional*|用户年龄|integer (int32)|
|**id**  <br>*optional*|用户编号|integer (int64)|
|**name**  <br>*optional*|用户姓名|string|



