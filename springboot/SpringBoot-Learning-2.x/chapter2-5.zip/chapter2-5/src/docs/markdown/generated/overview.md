# spring-boot-starter-swagger


<a name="overview"></a>
## Overview
Starter for swagger 2.x


### Version information
*Version* : 1.9.0.RELEASE


### Contact information
*Contact* : didi  
*Contact Email* : dyc87112@qq.com


### License information
*License* : Apache License, Version 2.0  
*License URL* : https://www.apache.org/licenses/LICENSE-2.0.html  
*Terms of service* : https://github.com/dyc87112/spring-boot-starter-swagger


### URI scheme
*Host* : localhost:8080  
*BasePath* : /


### Tags

* 用户管理 : User Controller



