$(function()
{
	console.log(screen.height)
  if (screen.height <= 900)
  {
  //     $(".xpanel-wrapper-left-one #echartsWarptop").css("height", "58%");
  //     $(".xpanel-wrapper-left-one #echartsWarpright").css("height", "58%");
  //     $(".xpanel-wrapper-centone .title").css("height", "8%");
  //     $("#allmap").css("height", "89%");
  //     $(".header").css({"height":"8%","margin-top":"10px"});
  //     $(".xpanel-wrapper-left-two .right_cent_li").css({"padding-top": "0","height":"85%"});
		$(".header").css("height", "11%");
		$(".header span").css("font-size","32px");
		
		$(".xpanel-wrapper-left-one .top .top_right").css("font-size","26px");
		$(".xpanel-wrapper-left-one .bott").css("padding-top","1%");
		$(".xpanel-wrapper-left-one .bott .bott_left").css("font-size","18px");
		$(".xpanel-wrapper-left-one .bott .bott_right").css("line-height","1.8");
		
		
		$(".xpanel-wrapper-cent-one .left .top .top_right").css("font-size","26px");
		$(".xpanel-wrapper-cent-one .left .bott").css("padding-top","1%");
		$(".xpanel-wrapper-cent-one .left .bott_left").css("font-size","18px");
		$(".xpanel-wrapper-cent-one .left .bott_right").css("line-height","1.8");
		
		$(".xpanel-wrapper-cent-one .right .top .top_right").css("font-size","26px");
		$(".xpanel-wrapper-cent-one .right .bott").css("padding-top","1%");
		$(".xpanel-wrapper-cent-one .right .bott_left").css("font-size","18px");
		$(".xpanel-wrapper-cent-one .right .bott_right").css("line-height","1.8");
		
		$(".xpanel-wrapper-right-one .top .top_right").css("font-size","26px");
		$(".xpanel-wrapper-right-one .bott").css("padding-top","1%");
		$(".xpanel-wrapper-right-one .bott .bott_left").css("font-size","18px");
		$(".xpanel-wrapper-right-one .bott .bott_right").css("line-height","1.8");
		
		$(".right_title").css("line-height","2.5");
		$(".xpanel-wrapper-cent-three .title").css("padding-top","10px");
		
		$(".xpanel-wrapper-cent-three .cont .tit").css({"height": "30px","line-height":"30px"});
		
		$(".xpanel-wrapper-cent-three .cont .tit li").css("font-size","14px");
		$(".xpanel-wrapper-cent-three .cont .list ul li p").css("font-size","12px");
		
		$(".xpanel-wrapper-right-one .top .top_right").css("font-size","26px");
		
		
		$(".xpanel-wrapper-cent-three .cont .list ul li").css({"height": "24px","line-height":"24px"});
		
		
		
		$(".scrollDiv").css("height","72px");
		$(".xpanel-wrapper-cent-one .right .top .top_left img").css("width","26px");
		$(".xpanel-wrapper-right-one .top .top_left img").css("width","28px");
		
		
		 
		
		
		
  };
});