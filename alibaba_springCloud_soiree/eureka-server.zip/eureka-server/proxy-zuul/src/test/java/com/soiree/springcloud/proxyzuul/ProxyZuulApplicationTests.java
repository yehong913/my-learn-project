package com.soiree.springcloud.proxyzuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyZuulApplicationTests {

    @Test
    void contextLoads() {
    }

}
