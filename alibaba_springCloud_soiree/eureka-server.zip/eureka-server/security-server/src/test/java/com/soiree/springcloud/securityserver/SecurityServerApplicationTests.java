package com.soiree.springcloud.securityserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
