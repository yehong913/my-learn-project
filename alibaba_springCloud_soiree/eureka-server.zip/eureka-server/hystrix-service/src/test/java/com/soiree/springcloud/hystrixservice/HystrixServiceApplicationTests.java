package com.soiree.springcloud.hystrixservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
